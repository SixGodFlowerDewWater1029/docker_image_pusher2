#!/bin/bash

cp -rf lsmod /usr/sbin
if [ $? -ne 0 ]; then
	echo -e "\033[34m cp lsmod failed... \033[0m"
	exit -1
fi
cp -rf libcrypto.so.1.1 /lib64
if [ $? -ne 0 ]; then
	echo -e "\033[34m cp libcrypto.so.1.1 failed... \033[0m"
	exit -2
fi

echo "install lsmod cmd success!"
